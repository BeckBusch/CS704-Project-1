package org.compsys704;

public class States {
	
	public static volatile int LIGHT = 0;
	public static volatile boolean FIRE = false;
	public static volatile boolean FAN = false;
	public static volatile boolean AC = false;
	public static volatile boolean HEAT = false;
}
