package run;

public class GUI implements java.lang.Runnable {
	public void run() {
		org.compsys704.CapLoader.main(null);
	}
}
